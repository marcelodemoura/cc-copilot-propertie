package br.com.mv.cccopilotpropertie.index;


public interface IndexService {

    IndexJob indexPath(String rootPath);
}