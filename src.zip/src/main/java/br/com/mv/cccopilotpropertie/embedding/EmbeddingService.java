package br.com.mv.cccopilotpropertie.embedding;

public interface EmbeddingService {

    float[] embed(String text);

}
