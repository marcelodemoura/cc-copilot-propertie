package br.com.mv.cccopilotpropertie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CcCopilotPropertieApplication {

	public static void main(String[] args) {
		SpringApplication.run(CcCopilotPropertieApplication.class, args);
	}

}
